import { useState, useEffect, useRef } from "react";

// ============================================================
// XOGTA TUSAALE AH (Demo Data)
// ============================================================
const DEMO_ARDAYDA = [
  { id: 1, magac: "Faadumo Xasan", tel: "+252 61 234 5678", koorso: "Web Development", xaalad: "Diiwaangeliyey", lacag: "Bixiyey", taarikh: "2025-05-20", magaalo: "Muqdisho" },
  { id: 2, magac: "Cabdiraxmaan Maxamed", tel: "+252 63 456 7890", koorso: "Data Science", xaalad: "Su'aal", lacag: "La sugayo", taarikh: "2025-05-22", magaalo: "Hargeysa" },
  { id: 3, magac: "Hodan Cali", tel: "+252 65 678 9012", koorso: "UI/UX Design", xaalad: "Diiwaangeliyey", lacag: "Bixiyey", taarikh: "2025-05-18", magaalo: "Muqdisho" },
  { id: 4, magac: "Maxamed Yuusuf", tel: "+252 61 890 1234", koorso: "Web Development", xaalad: "Diiwaangeliyey", lacag: "Qorshe", taarikh: "2025-05-21", magaalo: "Kismaayo" },
  { id: 5, magac: "Saynab Ibraahim", tel: "+252 63 012 3456", koorso: "Cybersecurity", xaalad: "Su'aal", lacag: "La sugayo", taarikh: "2025-05-23", magaalo: "Muqdisho" },
  { id: 6, magac: "Cumar Sheekh", tel: "+252 65 234 5678", koorso: "Data Science", xaalad: "Diiwaangeliyey", lacag: "Bixiyey", taarikh: "2025-05-19", magaalo: "Baydabo" },
  { id: 7, magac: "Nasteexo Warsame", tel: "+252 61 456 7890", koorso: "UI/UX Design", xaalad: "Joojiyey", lacag: "La sugayo", taarikh: "2025-05-15", magaalo: "Muqdisho" },
  { id: 8, magac: "Axmed Xirsi", tel: "+252 63 678 9012", koorso: "Web Development", xaalad: "Diiwaangeliyey", lacag: "Bixiyey", taarikh: "2025-05-24", magaalo: "Garoowe" },
];

const TODOOBAADLE_XOGTA = [
  { toddobaad: "Asb 1", suaal: 12, diiwaan: 4, lacag: 400 },
  { toddobaad: "Asb 2", suaal: 18, diiwaan: 7, lacag: 700 },
  { toddobaad: "Asb 3", suaal: 15, diiwaan: 5, lacag: 500 },
  { toddobaad: "Asb 4", suaal: 24, diiwaan: 10, lacag: 1000 },
  { toddobaad: "Asb 5", suaal: 30, diiwaan: 14, lacag: 1400 },
  { toddobaad: "Asb 6", suaal: 22, diiwaan: 9, lacag: 900 },
];

const KOORSOOYIN = ["Web Development", "Data Science", "UI/UX Design", "Cybersecurity", "Digital Marketing"];

const SYSTEM_PROMPT = `Waxaad tahay AI Student Recruitment Agent-ka academy-da dijitaalka ah ee Somalia. Hadafkaagu waa in aad kordhiso diiwaangelinta ardayda.

Waxaad raacaysaa wareeggan: Falanqee → Qorshee → Fulii → Dib-u-eeg → Wanaaaji

JAWAAB KASTA, qayamahaan isticmaal:
## 🔍 FALANQEE
## 📋 QORSHEE  
## ⚡ FULII
## 📊 DIB-U-EEG
## 🚀 WANAAAJI

Af Soomaali ku jawaab. Xaaladda Somalia tixgeli: mobile-first, WhatsApp, qiimaha jaban, kalsoonta bulshada.`;

// ============================================================
// MIDABADA & QAABKA
// ============================================================
const C = {
  bg: "#080A0F", bg2: "#0F1117", bg3: "#161B24", bg4: "#1C2333",
  gold: "#F0B429", gold2: "#E09020", green: "#2DD4A0", red: "#F06060",
  blue: "#4A9EFF", purple: "#9B6DFF", text: "#E8EDF5", muted: "rgba(232,237,245,0.45)",
  border: "rgba(240,180,41,0.12)", border2: "rgba(255,255,255,0.07)",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:${C.bg};color:${C.text};font-family:'Outfit',sans-serif;overflow:hidden}
  ::-webkit-scrollbar{width:3px;height:3px}
  ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:2px}
  @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
  @keyframes bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}
  @keyframes spin{to{transform:rotate(360deg)}}
  input,select,textarea{font-family:'Outfit',sans-serif}
  input:focus,select:focus,textarea:focus{outline:none}
`;

// ============================================================
// COMPONENTS YARYAR
// ============================================================
function Kaadhka({ title, qiime, icon, midab, isbedel }) {
  return (
    <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, padding: "20px 22px", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${midab}, transparent)` }} />
      <div style={{ fontSize: 11, color: C.muted, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>{title}</div>
      <div style={{ fontSize: 32, fontWeight: 800, color: midab, fontFamily: "'JetBrains Mono'" }}>{qiime}</div>
      {isbedel && <div style={{ fontSize: 12, color: C.green, marginTop: 6, fontWeight: 600 }}>↑ {isbedel} asbuucaan</div>}
      <div style={{ position: "absolute", right: 18, top: 18, fontSize: 28, opacity: .15 }}>{icon}</div>
    </div>
  );
}

function MiniChart({ xogta, midab }) {
  const max = Math.max(...xogta.map(d => d.diiwaan));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 50 }}>
      {xogta.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
          <div style={{ width: "100%", background: `${midab}30`, borderRadius: "3px 3px 0 0", height: (d.diiwaan / max) * 40, transition: "height .5s ease", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: midab, height: `${(d.diiwaan / max) * 100}%`, borderRadius: "3px 3px 0 0" }} />
          </div>
          <div style={{ fontSize: 8, color: C.muted }}>{d.toddobaad.split(" ")[1]}</div>
        </div>
      ))}
    </div>
  );
}

function XaaladBadge({ xaalad }) {
  const colors = { "Diiwaangeliyey": C.green, "Su'aal": C.gold, "Joojiyey": C.red };
  const c = colors[xaalad] || C.muted;
  return (
    <span style={{ background: `${c}18`, color: c, padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, border: `1px solid ${c}30` }}>{xaalad}</span>
  );
}

function LacagBadge({ xaalad }) {
  const colors = { "Bixiyey": C.green, "La sugayo": C.gold, "Qorshe": C.blue };
  const c = colors[xaalad] || C.muted;
  return (
    <span style={{ background: `${c}15`, color: c, padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600 }}>{xaalad}</span>
  );
}

// ============================================================
// QAYBAHA WEYN
// ============================================================

// 1. DASHBOARD
function Dashboard({ ardayda }) {
  const diiwaangeliyey = ardayda.filter(a => a.xaalad === "Diiwaangeliyey").length;
  const suaal = ardayda.filter(a => a.xaalad === "Su'aal").length;
  const lacagBixiyey = ardayda.filter(a => a.lacag === "Bixiyey").length;
  const lacagTotal = lacagBixiyey * 150;

  return (
    <div style={{ padding: "24px", overflowY: "auto", height: "100%" }}>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Xaashida Guud 📊</h2>
        <p style={{ color: C.muted, fontSize: 14 }}>Warbixinta maanta — {new Date().toLocaleDateString('so-SO')}</p>
      </div>

      {/* Stats Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
        <Kaadhka title="Ardayda Guud" qiime={ardayda.length} icon="🎓" midab={C.blue} isbedel="+3" />
        <Kaadhka title="Diiwaangeliyey" qiime={diiwaangeliyey} icon="✅" midab={C.green} isbedel="+2" />
        <Kaadhka title="Su'aalaha" qiime={suaal} icon="💬" midab={C.gold} isbedel="+5" />
        <Kaadhka title="Lacagta ($)" qiime={`$${lacagTotal}`} icon="💰" midab={C.purple} isbedel="+$300" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14, marginBottom: 14 }}>
        {/* Toddobaadlaha Chart */}
        <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, padding: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 16, display: "flex", justifyContent: "space-between" }}>
            <span>Diiwaangelinta Toddobaadlaha</span>
            <span style={{ color: C.green, fontSize: 12 }}>↑ 40% bilahan</span>
          </div>
          <MiniChart xogta={TODOOBAADLE_XOGTA} midab={C.green} />
          <div style={{ display: "flex", gap: 16, marginTop: 14 }}>
            {TODOOBAADLE_XOGTA.slice(-3).map((d, i) => (
              <div key={i} style={{ flex: 1, background: C.bg4, borderRadius: 8, padding: "10px 12px", textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: C.green, fontFamily: "'JetBrains Mono'" }}>{d.diiwaan}</div>
                <div style={{ fontSize: 10, color: C.muted }}>{d.toddobaad}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Kooray chart */}
        <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, padding: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 16 }}>Koorsada ugu Caan</div>
          {KOORSOOYIN.map((k, i) => {
            const tiro = ardayda.filter(a => a.koorso === k).length;
            const boqolkiiba = Math.round((tiro / ardayda.length) * 100);
            const midabyo = [C.blue, C.green, C.gold, C.purple, C.red];
            return (
              <div key={i} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 5 }}>
                  <span style={{ color: C.muted }}>{k}</span>
                  <span style={{ fontWeight: 700, color: midabyo[i] }}>{tiro} ardayda</span>
                </div>
                <div style={{ background: C.bg4, borderRadius: 4, height: 6, overflow: "hidden" }}>
                  <div style={{ width: `${boqolkiiba}%`, background: midabyo[i], height: "100%", borderRadius: 4, transition: "width 1s ease" }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Magaalooyinka */}
      <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Magaalooyinka Ardayda 🗺️</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {["Muqdisho", "Hargeysa", "Kismaayo", "Garoowe", "Baydabo"].map(m => {
            const tiro = ardayda.filter(a => a.magaalo === m).length;
            return (
              <div key={m} style={{ background: C.bg4, border: `1px solid ${C.border2}`, borderRadius: 10, padding: "10px 16px", textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 800, color: C.gold }}>{tiro}</div>
                <div style={{ fontSize: 11, color: C.muted }}>{m}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// 2. CRM
function CRM({ ardayda, setArdayda }) {
  const [raadi, setRaadi] = useState("");
  const [filter, setFilter] = useState("Dhammaan");
  const [muujinArday, setMuujinArday] = useState(null);
  const [cusub, setCusub] = useState(false);
  const [foomka, setFoomka] = useState({ magac: "", tel: "", koorso: "Web Development", magaalo: "Muqdisho", xaalad: "Su'aal", lacag: "La sugayo" });

  const la_cayimay = ardayda.filter(a => {
    const match = a.magac.toLowerCase().includes(raadi.toLowerCase()) || a.tel.includes(raadi);
    const filterMatch = filter === "Dhammaan" || a.xaalad === filter;
    return match && filterMatch;
  });

  const kuDar = () => {
    if (!foomka.magac || !foomka.tel) return;
    setArdayda(prev => [...prev, { ...foomka, id: Date.now(), taarikh: new Date().toISOString().split("T")[0] }]);
    setCusub(false);
    setFoomka({ magac: "", tel: "", koorso: "Web Development", magaalo: "Muqdisho", xaalad: "Su'aal", lacag: "La sugayo" });
  };

  const tirtir = (id) => { setArdayda(prev => prev.filter(a => a.id !== id)); setMuujinArday(null); };

  return (
    <div style={{ padding: "24px", overflowY: "auto", height: "100%" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Maamulka Ardayda 👥</h2>
          <p style={{ color: C.muted, fontSize: 14 }}>{ardayda.length} arday oo diiwaanka ah</p>
        </div>
        <button onClick={() => setCusub(true)} style={{ background: C.gold, color: "#000", border: "none", padding: "10px 20px", borderRadius: 10, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'Outfit'" }}>+ Arday Cusub</button>
      </div>

      {/* Raadinta & Filter */}
      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <input value={raadi} onChange={e => setRaadi(e.target.value)} placeholder="🔍 Raadi magac ama tel..."
          style={{ flex: 1, background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 10, padding: "10px 14px", color: C.text, fontSize: 14 }} />
        {["Dhammaan", "Diiwaangeliyey", "Su'aal", "Joojiyey"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ padding: "10px 16px", borderRadius: 10, border: `1px solid ${filter === f ? C.gold : C.border2}`, background: filter === f ? `${C.gold}15` : C.bg3, color: filter === f ? C.gold : C.muted, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "'Outfit'", whiteSpace: "nowrap" }}>{f}</button>
        ))}
      </div>

      {/* Jadwalka */}
      <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, overflow: "hidden" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1.5fr 1.5fr 1fr 1fr 80px", padding: "12px 16px", borderBottom: `1px solid ${C.border2}`, fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase" }}>
          <span>Magaca</span><span>Koorso</span><span>Magaalo</span><span>Xaalad</span><span>Lacag</span><span>Ficil</span>
        </div>
        {la_cayimay.map(a => (
          <div key={a.id} onClick={() => setMuujinArday(a)} style={{ display: "grid", gridTemplateColumns: "2fr 1.5fr 1.5fr 1fr 1fr 80px", padding: "14px 16px", borderBottom: `1px solid ${C.border2}`, cursor: "pointer", transition: "background .15s" }}
            onMouseEnter={e => e.currentTarget.style.background = C.bg4}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{a.magac}</div>
              <div style={{ fontSize: 12, color: C.muted }}>{a.tel}</div>
            </div>
            <div style={{ fontSize: 13, color: C.muted, alignSelf: "center" }}>{a.koorso}</div>
            <div style={{ fontSize: 13, color: C.muted, alignSelf: "center" }}>{a.magaalo}</div>
            <div style={{ alignSelf: "center" }}><XaaladBadge xaalad={a.xaalad} /></div>
            <div style={{ alignSelf: "center" }}><LacagBadge xaalad={a.lacag} /></div>
            <div style={{ alignSelf: "center", display: "flex", gap: 6 }}>
              <button onClick={e => { e.stopPropagation(); tirtir(a.id); }} style={{ background: `${C.red}15`, color: C.red, border: "none", padding: "5px 10px", borderRadius: 6, fontSize: 12, cursor: "pointer" }}>🗑</button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Arday Details */}
      {muujinArday && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setMuujinArday(null)}>
          <div style={{ background: C.bg2, border: `1px solid ${C.border2}`, borderRadius: 20, padding: 32, width: 400, animation: "fadeUp .2s ease" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <h3 style={{ fontSize: 20, fontWeight: 800 }}>{muujinArday.magac}</h3>
              <button onClick={() => setMuujinArday(null)} style={{ background: "none", border: "none", color: C.muted, fontSize: 20, cursor: "pointer" }}>✕</button>
            </div>
            {[["📱 Telefoon", muujinArday.tel], ["🎓 Koorso", muujinArday.koorso], ["🏙 Magaalo", muujinArday.magaalo], ["📅 Taariikhda", muujinArday.taarikh]].map(([l, v]) => (
              <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: `1px solid ${C.border2}`, fontSize: 14 }}>
                <span style={{ color: C.muted }}>{l}</span><span style={{ fontWeight: 600 }}>{v}</span>
              </div>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <XaaladBadge xaalad={muujinArday.xaalad} /><LacagBadge xaalad={muujinArday.lacag} />
            </div>
            <a href={`https://wa.me/${muujinArday.tel.replace(/\s+/g, "")}`} target="_blank" style={{ display: "block", background: "#25D366", color: "#fff", textAlign: "center", padding: "12px", borderRadius: 10, marginTop: 20, fontWeight: 700, fontSize: 14, textDecoration: "none" }}>📱 WhatsApp Dir</a>
          </div>
        </div>
      )}

      {/* Modal: Arday Cusub */}
      {cusub && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setCusub(false)}>
          <div style={{ background: C.bg2, border: `1px solid ${C.border2}`, borderRadius: 20, padding: 32, width: 420, animation: "fadeUp .2s ease" }} onClick={e => e.stopPropagation()}>
            <h3 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>➕ Arday Cusub Ku Dar</h3>
            {[["Magaca", "magac", "text"], ["Telefoon", "tel", "tel"]].map(([l, k, t]) => (
              <div key={k} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>{l}</label>
                <input type={t} value={foomka[k]} onChange={e => setFoomka(p => ({ ...p, [k]: e.target.value }))} style={{ width: "100%", background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 8, padding: "10px 12px", color: C.text, fontSize: 14 }} />
              </div>
            ))}
            {[["Koorso", "koorso", KOORSOOYIN], ["Magaalo", "magaalo", ["Muqdisho", "Hargeysa", "Kismaayo", "Garoowe", "Baydabo"]], ["Xaalad", "xaalad", ["Su'aal", "Diiwaangeliyey", "Joojiyey"]]].map(([l, k, opts]) => (
              <div key={k} style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>{l}</label>
                <select value={foomka[k]} onChange={e => setFoomka(p => ({ ...p, [k]: e.target.value }))} style={{ width: "100%", background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 8, padding: "10px 12px", color: C.text, fontSize: 14 }}>
                  {opts.map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
              <button onClick={() => setCusub(false)} style={{ flex: 1, background: C.bg3, border: `1px solid ${C.border2}`, color: C.muted, padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit'" }}>Jooji</button>
              <button onClick={kuDar} style={{ flex: 2, background: C.gold, color: "#000", border: "none", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit'" }}>✓ Ku Dar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// 3. PAYMENT
function Payment({ ardayda }) {
  const [qaabka, setQaabka] = useState("EVC Plus");
  const [xaaladda, setXaaladda] = useState(null);
  const [foomka, setFoomka] = useState({ magac: "", tel: "", koorso: "Web Development", lacag: "150" });
  const [loading, setLoading] = useState(false);

  const bixiLacag = () => {
    if (!foomka.magac || !foomka.tel) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setXaaladda("guul");
    }, 2000);
  };

  return (
    <div style={{ padding: "24px", overflowY: "auto", height: "100%" }}>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Lacag-bixinta 💳</h2>
        <p style={{ color: C.muted, fontSize: 14 }}>Qaab kasta oo kugu dhaqso</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Foomka */}
        <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 16, padding: 24 }}>
          <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 18 }}>Xog-ururin Lacag-bixinta</div>

          {/* Qaabka lacag bixinta */}
          <div style={{ marginBottom: 18 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 10 }}>Qaabka</label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[
                { magac: "EVC Plus", icon: "📱", midab: "#FF7300" },
                { magac: "Zaad", icon: "📲", midab: "#0077C8" },
                { magac: "Stripe", icon: "💳", midab: "#635BFF" },
                { magac: "Bank", icon: "🏦", midab: C.gold },
              ].map(q => (
                <button key={q.magac} onClick={() => setQaabka(q.magac)} style={{ padding: "12px", borderRadius: 10, border: `2px solid ${qaabka === q.magac ? q.midab : C.border2}`, background: qaabka === q.magac ? `${q.midab}15` : C.bg4, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, transition: "all .2s", fontFamily: "'Outfit'" }}>
                  <span style={{ fontSize: 20 }}>{q.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: qaabka === q.magac ? q.midab : C.muted }}>{q.magac}</span>
                </button>
              ))}
            </div>
          </div>

          {[["Magaca Ardayga", "magac", "text", "Faadumo Xasan"], ["Lambarka Telefoonka", "tel", "tel", "+252 61 XXX XXXX"]].map(([l, k, t, ph]) => (
            <div key={k} style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>{l}</label>
              <input type={t} placeholder={ph} value={foomka[k]} onChange={e => setFoomka(p => ({ ...p, [k]: e.target.value }))} style={{ width: "100%", background: C.bg4, border: `1px solid ${C.border2}`, borderRadius: 8, padding: "11px 14px", color: C.text, fontSize: 14 }} />
            </div>
          ))}

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>Koorso</label>
              <select value={foomka.koorso} onChange={e => setFoomka(p => ({ ...p, koorso: e.target.value }))} style={{ width: "100%", background: C.bg4, border: `1px solid ${C.border2}`, borderRadius: 8, padding: "11px 12px", color: C.text, fontSize: 13 }}>
                {KOORSOOYIN.map(k => <option key={k}>{k}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>Lacagta ($)</label>
              <select value={foomka.lacag} onChange={e => setFoomka(p => ({ ...p, lacag: e.target.value }))} style={{ width: "100%", background: C.bg4, border: `1px solid ${C.border2}`, borderRadius: 8, padding: "11px 12px", color: C.text, fontSize: 13 }}>
                {["150", "100", "75", "50"].map(l => <option key={l}>${l}</option>)}
              </select>
            </div>
          </div>

          <button onClick={bixiLacag} disabled={loading} style={{ width: "100%", background: loading ? C.bg4 : `linear-gradient(135deg, ${C.gold}, ${C.gold2})`, color: loading ? C.muted : "#000", border: "none", padding: "14px", borderRadius: 10, fontWeight: 800, fontSize: 15, cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Outfit'", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            {loading ? <><span style={{ display: "inline-block", width: 16, height: 16, border: "2px solid #fff3", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 1s linear infinite" }} /> Xaqiijinaya...</> : `✓ Xaqiiji Lacag-bixinta — $${foomka.lacag}`}
          </button>
        </div>

        {/* Dhinaca midig */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Guusha */}
          {xaaladda === "guul" && (
            <div style={{ background: `${C.green}10`, border: `1px solid ${C.green}30`, borderRadius: 16, padding: 24, textAlign: "center", animation: "fadeUp .3s ease" }}>
              <div style={{ fontSize: 48, marginBottom: 10 }}>✅</div>
              <div style={{ fontSize: 18, fontWeight: 800, color: C.green, marginBottom: 6 }}>Lacagta Waa La Xaqiijiyay!</div>
              <div style={{ color: C.muted, fontSize: 13 }}>SMS xaqiijin ah ayaa loo diray {foomka.tel}</div>
            </div>
          )}

          {/* Soo xusuusta */}
          <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 16, padding: 20 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Lacagaha Socda ⏰</div>
            {ardayda.filter(a => a.lacag === "La sugayo").slice(0, 4).map(a => (
              <div key={a.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border2}` }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{a.magac}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{a.koorso}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: C.gold, fontWeight: 700, fontFamily: "'JetBrains Mono'" }}>$150</div>
                  <LacagBadge xaalad={a.lacag} />
                </div>
              </div>
            ))}
          </div>

          {/* Xog lacag */}
          <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 16, padding: 20 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Xogta Lacagta 💰</div>
            {[
              { label: "Waa La Helay", qiime: `$${ardayda.filter(a => a.lacag === "Bixiyey").length * 150}`, midab: C.green },
              { label: "La Sugayo", qiime: `$${ardayda.filter(a => a.lacag === "La sugayo").length * 150}`, midab: C.gold },
              { label: "Qorshaha", qiime: `$${ardayda.filter(a => a.lacag === "Qorshe").length * 150}`, midab: C.blue },
            ].map(x => (
              <div key={x.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border2}` }}>
                <span style={{ color: C.muted, fontSize: 13 }}>{x.label}</span>
                <span style={{ fontFamily: "'JetBrains Mono'", fontWeight: 700, color: x.midab, fontSize: 16 }}>{x.qiime}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// 4. AI AGENT
function AIAgent() {
  const [farriimaha, setFarriimaha] = useState([{
    role: "assistant",
    content: "Salaan! 👋 Waxaan ahay AI Wakiilkaaga Aqoon-baadhistada.\n\nMaxaad maanta shaqeynaysaa?\n🎯 Olaha diiwaangelinta\n📱 Xeeladda WhatsApp\n📊 Dib-u-eegista toddobaadka\n🎓 Fursadda Deeqaha",
    waqti: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
  }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [farriimaha, loading]);

  const dir = async (text) => {
    const qoraal = text || input.trim();
    if (!qoraal || loading) return;
    setInput("");
    const cusub = [...farriimaha, { role: "user", content: qoraal, waqti: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }];
    setFarriimaha(cusub);
    setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, system: SYSTEM_PROMPT, messages: cusub.map(m => ({ role: m.role, content: m.content })) }),
      });
      const data = await res.json();
      const jawaab = data.content?.map(b => b.text || "").join("") || "Khalad ayaa dhacay.";
      setFarriimaha(p => [...p, { role: "assistant", content: jawaab, waqti: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }]);
    } catch { setFarriimaha(p => [...p, { role: "assistant", content: "⚠️ Xiriirka wuu go'ay.", waqti: "" }]); }
    setLoading(false);
  };

  const PROMPTS_DEGDEG = [
    "Samee ololaha diiwaangelinta Web Development", "Noo samee xeeladda WhatsApp",
    "Falanqee: 45 booqasho, 12 su'aal, 3 diiwaangelin", "Samee ogeysiiska deeqaha"
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Farriimaha */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>
        {farriimaha.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 14, animation: "fadeUp .25s ease" }}>
            {m.role === "assistant" && (
              <div style={{ width: 34, height: 34, borderRadius: "50%", background: `linear-gradient(135deg, ${C.gold}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, marginRight: 10, flexShrink: 0 }}>🤖</div>
            )}
            <div style={{ maxWidth: "78%", background: m.role === "user" ? `linear-gradient(135deg, ${C.purple}, #7B5FDD)` : C.bg3, border: m.role === "user" ? "none" : `1px solid ${C.border2}`, borderRadius: m.role === "user" ? "16px 3px 16px 16px" : "3px 16px 16px 16px", padding: "12px 16px", fontSize: 13.5, lineHeight: 1.75, whiteSpace: "pre-wrap" }}>
              {m.content}
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 5, textAlign: "right" }}>{m.waqti}</div>
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
            <div style={{ width: 34, height: 34, borderRadius: "50%", background: `linear-gradient(135deg, ${C.gold}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>🤖</div>
            <div style={{ background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: "3px 16px 16px 16px", padding: "14px 18px", display: "flex", gap: 5 }}>
              {[0, 1, 2].map(i => <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: C.gold, animation: `bounce 1.2s ${i * .2}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Prompts Degdeg */}
      <div style={{ padding: "0 24px 10px", display: "flex", gap: 7, overflowX: "auto" }}>
        {PROMPTS_DEGDEG.map((p, i) => (
          <button key={i} onClick={() => dir(p)} style={{ flexShrink: 0, padding: "7px 14px", borderRadius: 20, background: C.bg3, border: `1px solid ${C.border2}`, color: C.muted, fontSize: 11, cursor: "pointer", fontFamily: "'Outfit'", whiteSpace: "nowrap", transition: "all .2s" }}
            onMouseEnter={e => { e.target.style.borderColor = C.gold; e.target.style.color = C.gold; }}
            onMouseLeave={e => { e.target.style.borderColor = C.border2; e.target.style.color = C.muted; }}>
            {p}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={{ padding: "0 24px 24px" }}>
        <div style={{ display: "flex", gap: 10, background: C.bg3, border: `1px solid ${C.border2}`, borderRadius: 14, padding: "10px 14px" }}>
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); dir(); } }}
            placeholder="Su'aashaada qor..." rows={1}
            style={{ flex: 1, background: "transparent", border: "none", color: C.text, fontSize: 14, resize: "none", fontFamily: "'Outfit'", lineHeight: 1.5, maxHeight: 80, overflowY: "auto" }} />
          <button onClick={() => dir()} disabled={!input.trim() || loading} style={{ width: 38, height: 38, borderRadius: 10, border: "none", background: input.trim() && !loading ? C.gold : C.bg4, color: input.trim() ? "#000" : C.muted, cursor: input.trim() ? "pointer" : "not-allowed", fontSize: 16, fontWeight: 800, transition: "all .2s" }}>↑</button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// APP WEYN
// ============================================================
export default function AcademySystem() {
  const [tab, setTab] = useState("dashboard");
  const [ardayda, setArdayda] = useState(DEMO_ARDAYDA);

  const TABYO = [
    { id: "dashboard", icon: "📊", label: "Guud" },
    { id: "crm", icon: "👥", label: "Ardayda" },
    { id: "payment", icon: "💳", label: "Lacag" },
    { id: "ai", icon: "🤖", label: "AI Agent" },
  ];

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: C.bg }}>
      <style>{css}</style>

      {/* HEADER */}
      <div style={{ padding: "0 24px", height: 58, display: "flex", alignItems: "center", justifyContent: "space-between", background: C.bg2, borderBottom: `1px solid ${C.border2}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: `linear-gradient(135deg, ${C.gold}, ${C.gold2})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🎓</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 15, letterSpacing: -.3, fontFamily: "'Outfit'" }}>Academy<span style={{ color: C.gold }}>AI</span></div>
            <div style={{ fontSize: 10, color: C.muted, letterSpacing: .5 }}>NIDAAMKA MAAMULKA</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: C.green, animation: "pulse 2s infinite" }} />
          <span style={{ fontSize: 12, color: C.green, fontWeight: 600 }}>Shaqeynaya</span>
        </div>
      </div>

      {/* JIDKA */}
      <div style={{ display: "flex", padding: "0 24px", background: C.bg2, borderBottom: `1px solid ${C.border2}`, flexShrink: 0 }}>
        {TABYO.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "12px 20px", border: "none", background: "none", cursor: "pointer", fontFamily: "'Outfit'", fontSize: 14, fontWeight: tab === t.id ? 700 : 500, color: tab === t.id ? C.gold : C.muted, borderBottom: `2px solid ${tab === t.id ? C.gold : "transparent"}`, transition: "all .2s", display: "flex", alignItems: "center", gap: 7 }}>
            <span>{t.icon}</span><span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* CONTENT */}
      <div style={{ flex: 1, overflow: "hidden" }}>
        {tab === "dashboard" && <Dashboard ardayda={ardayda} />}
        {tab === "crm" && <CRM ardayda={ardayda} setArdayda={setArdayda} />}
        {tab === "payment" && <Payment ardayda={ardayda} />}
        {tab === "ai" && <AIAgent />}
      </div>
    </div>
  );
}
